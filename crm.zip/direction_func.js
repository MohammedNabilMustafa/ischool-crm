

//local
// var database_fixed_link = "http://localhost/ischool-crm/fetch.php";
// var database_fixed_link_history = "http://localhost/ischool-crm/fetch_history.php";
// var return_page = "http://localhost/ischool-crm/success/index.html";
// var reg_page =  "http://localhost/ischool-crm/reg/"
// var dash_page =  "http://localhost/ischool-crm/dashboard/"
// var free_page =  "http://localhost/ischool-crm/free/"

//public
var database_fixed_link = "https://operation.ischool-edu.com/fetch.php";
var database_fixed_link_history = "https://operation.ischool-edu.com/fetch_history.php";
var return_page = 'https://operation.ischool-edu.com/success/';
var reg_page =  "https://operation.ischool-edu.com/reg/"
var dash_page =  "https://operation.ischool-edu.com/dashboard/"
var free_page =  "https://operation.ischool-edu.com/free/"