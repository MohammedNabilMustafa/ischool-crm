

var st_ids = 0;
var saved_group_arr = []

var saved_age_arr = []
var saved_status_arr = []

function ADD_NEW_PARENT_GROUPS()
{

    var Database_link = "http://localhost/iSchool/fetch.php"
    var inputs_col = [["name" , "slot" ],
    ["name"],
    ["name"],
    ["name"],
    ["name"],
    ["name"],
    ["name"],
    ["name"],
    ["slot_id" 
    , "lan_id" 
    , "att_id" 
    , "level_id" 
    , "track_id" 
    , "type_id" 
    , "days_id" 
    , "age_id" 
    , "opend_by" 
    , "start_date" 
    , "end_date" 
    ],
    ["std_id" 
    , "group_id" 
    , "parent_id" 
    , "free_session_status" 
    , "std_status" 
    , "name" 
    , "age" 
    , "birthdate" 
    ]
    ,
    ["groups_id" 
    , "student_id" 
    , "status" 
    ],
    ["name"],

  ];

var called_table = ['slots',
      'lan',
      'attend',
      'level',
      'track',
      'session_type',
      'days',
      'Age',
      'groups',
      'students',
      'student_groups',
      'operation_status'
  ];

        const All_req_obj_ = {};
        All_req_obj_.Database_link = Database_link
        All_req_obj_.inputs_col = inputs_col
        All_req_obj_.called_table = called_table
                 
  
    get_paper_tables_parent(All_req_obj_ ,quary_tables_all_status_groups_check , '' , 5  , 4);

}


function ADD_NEW_PARENT()
{
    saved_group_arr = []
    saved_age_arr = []

    st_ids = 0;
    document.getElementById("Location_1").innerHTML = "";
    document.getElementById("Location_2").innerHTML = "";
    document.getElementById("Location_3").innerHTML = "";
    //document.getElementById("Location_4").innerHTML = "";
    document.getElementById("search-results").innerHTML = "";

    var Database_link = "http://localhost/iSchool/fetch.php"
    var inputs_col = [
        ["name"],
        ["name"],
        ["name"],
        ["name" 
        , "phone" 
        , "email" 
        , "zoomlink" 
        , "username" 
        , "password" 
        , "permission_id" 
        , "department_id" 
        , "role_id" 
         ],
         ["name" 
         , "phone" 
         , "email" 
         , "name_2" 
         , "phone_2" 
         , "email_2" 
         , "address" 
         , "location" 
         , "job" 
         , "reg_status" 
         , "customer_agent_id" 
         , "sales_agent_id" 
          ]
          ,
         ["std_id" 
         , "parent_id" 
         , "free_session_status" 
         , "std_status" 
         , "name" 
         , "age" 
         , "birthdate" 
          ],
          ["slot_id" 
          , "lan_id" 
          , "att_id" 
          , "level_id" 
          , "track_id" 
          , "type_id" 
          , "days_id" 
          , "age_id" 
          , "opend_by" 
          , "start_date" 
          , "end_date" 
          , "student_id_1" 
          , "student_id_2" 
          , "student_id_3" 
          , "student_id_4" 
          , "student_id_5" 
          , "student_id_6" 
          ],
          ["name"],
          ["groups_id" 
          , "student_id" 
          , "status" 
          ],
          ["name"],
          ["name"],
          ["name"],
          ["name"],
          ["name"],
          ["name"],
          ["name"],
          ["name"],
          ["name"]


      ];

var called_table = ['permission',
          'department',
          'role',
          'employee',
          'parent',
          'students',
          'groups',
          'age',
          'student_groups',
          'operation_status',
          'slots',
          'lan',
          'attend',
          'level',
          'track',
          'session_type',
          'days',
          'Age',

      ];

var paper_inputs = ['name_input' , 
          'phone_input',
          'email_input',
          'name2_input',
          'phone2_input',
          'email2_input',
          'address_input',
          'location_input',
          'job_input',
          'reg_status_input',
          'customer_input',
          'sales_input',

      ];



var paper_inputs_label = [
          'Name : ' , 
          'Phone : ',
          'Email : ',
          'Name 2 : ',
          'Phone 2 : ',
          'Email 2 : ',
          'Address : ',
          'Location : ',
          'Job : ',
          'Register Status : ',
          'Customer Agent ',
          'Sales Agent '


      ];

        const All_req_obj = {};
        All_req_obj.Database_link = Database_link
        All_req_obj.inputs_col = inputs_col
        All_req_obj.called_table = called_table
                 
    html_create_lists_parent(paper_inputs , paper_inputs_label , "Location_1" );
    get_paper_tables_parent(All_req_obj ,quary_tables_all_employee , quary_tables_all_status_parent , 5  , 1);


    add_new_parent_(All_req_obj,paper_inputs);
    get_paper_tables_parent(All_req_obj ,quary_tables_all_parent,create_paper_table_parent , 5 , 2);

    $('#search_btn').click(function (index) {  

    get_paper_tables_parent(All_req_obj ,quary_tables_all_parent,create_paper_table_customized_parent , 5 , 3);
        });
  
    $('#add_student_new').click(function () {  

        html_create_lists_student_num(All_req_obj,paper_inputs ,"Location_2" , st_ids);
        st_ids++;
    });

    ADD_NEW_PARENT_GROUPS();

}
function html_create_lists_student_num(All_req_obj , paper_inputs ,location_ , st_ids_)
{
    document.getElementById(location_).innerHTML +=`<div class="col"><div class="form-floating mb-3 search_adjust">`;


    document.getElementById(location_).innerHTML += `<label>Student ID : </label><input type='text' id='student_id`+st_ids_+`'>`;
    document.getElementById(location_).innerHTML += `<label>Name : </label><input type='text' id='name_id`+st_ids_+`'>`;

    document.getElementById(location_).innerHTML +=`</div></div>`;
    document.getElementById(location_).innerHTML += `<label>Free Session : </label><input class="largerCheckbox" type='checkbox' id='free_id`+st_ids_+`' value='yes'>`;

    document.getElementById(location_).innerHTML +=`<div class="col"><div class="form-floating mb-3 search_adjust">`;
    document.getElementById(location_).innerHTML += `<label>birthdate : </label><input type='date' id='bd_id`+st_ids_+`'>`;
    paper_inner_parent_1('status_id'+st_ids_ , "Status ");

    for(var index = 0 ;index < saved_status_arr.length ; index++)
    {
        $('#status_id'+st_ids_).append(`<option value="${saved_status_arr[index][0]}"
        >${saved_status_arr[index][1]} </option>`); 
    }
    document.getElementById(location_).innerHTML +=`</div></div>`;

    paper_inner_parent_1('groups_id_input'+st_ids_ , "Groups ");

    for(var index = 0 ;index < saved_group_arr.length ; index++)
    {
        $('#groups_id_input'+st_ids_).append(`<option value="${saved_group_arr[index][0]}"
        >${saved_group_arr[index][1]} </option>`); 
    }

    document.getElementById(location_).innerHTML +=`<div class="col"><div class="form-floating mb-3 search_adjust">`;
    document.getElementById(location_).innerHTML +=`<hr class="hr-primary" />`;
    document.getElementById(location_).innerHTML +=`</div></div>`;


    // saved_group_arr

}

function html_create_lists_parent(paper_inputs , paper_inputs_label  , location_)
{
    document.getElementById("Location_1").innerHTML = "";
    document.getElementById("Location_2").innerHTML = "";
    document.getElementById("Location_3").innerHTML = "";
    //document.getElementById("Location_4").innerHTML = "";
    document.getElementById("search-results").innerHTML = "";



    //  `<div class='col justify-content-start'><button class='btn btn-danger' style='float:left;' id='add_back'>BACK</button></div>`;
    
    document.getElementById(location_).innerHTML +=`<div class="col"><div class="form-floating mb-3 search_adjust">`;

    for(var index = 0 ; index < 3 ; index++)
    {
        document.getElementById(location_).innerHTML += `<label>`+paper_inputs_label[index]+` </label><input type='text' id='`+paper_inputs[index]+`'>`;
    }
    document.getElementById(location_).innerHTML +=`</div></div>`;

    document.getElementById(location_).innerHTML +=`<div class="col"><div class="form-floating mb-3 search_adjust">`;

    for(var index = 3 ; index < 6 ; index++)
    {
        document.getElementById(location_).innerHTML += `<label>`+paper_inputs_label[index]+` </label><input type='text' id='`+paper_inputs[index]+`'>`;
    }
    document.getElementById(location_).innerHTML +=`</div></div>`;

    document.getElementById(location_).innerHTML +=`<div class="col"><div class="form-floating mb-3 search_adjust">`;

    for(var index = 6 ; index < 10 ; index++)
    {
        document.getElementById(location_).innerHTML += `<label>`+paper_inputs_label[index]+` </label><input type='text' id='`+paper_inputs[index]+`'>`;
    }
    document.getElementById(location_).innerHTML +=`</div></div>`;

    document.getElementById(location_).innerHTML +=`<div class="col"><div class="form-floating mb-3 search_adjust">`;

    for(var index = 10 ; index < 12 ; index++)
    {
        paper_inner_parent(paper_inputs[index] , paper_inputs_label[index]);
    }
    document.getElementById(location_).innerHTML +=`</div></div>`;


    document.getElementById(location_).innerHTML += `<div class='col justify-content-start'><button class='btn btn-success' style='float:right;' id='send_group'>ADD</button></div>`;


    document.getElementById(location_).innerHTML +=`<div class="input-group">
    <div class='col justify-content-start'>
      <input type="search" id="search_all" class="form-control" />
    </div>
    <div class='col justify-content-start'><button type="button" id='search_btn' class="btn btn-primary">
      <i class="fas fa-search"></i>
    </button></div>
  </div>`;
  document.getElementById(location_).innerHTML +=`<div class="col"><div class="form-floating mb-3 search_adjust">`;
  document.getElementById(location_).innerHTML +=`</div></div>`;

  document.getElementById(location_).innerHTML +=`<div class='col justify-content-start'><button class='btn btn-primary' style='float:left;' id='add_student_new'>+ ADD Student</button></div><br>`;
    
  document.getElementById(location_).innerHTML +=`<div class="col"><div class="form-floating mb-3 search_adjust">`;
  document.getElementById(location_).innerHTML +=`<hr class="hr-primary" />`;
  document.getElementById(location_).innerHTML +=`</div></div>`;

}

function add_new_parent_(All_req_obj,paper_inputs )
{
    
    var Database_link = "http://localhost/iSchool/fetch.php"

    var inputs_col = 
    ["name" 
    , "phone" 
    , "email" 
    , "name_2" 
    , "phone_2" 
    , "email_2" 
    , "address" 
    , "location" 
    , "job" 
    , "reg_status" 
    , "customer_agent_id" 
    , "sales_agent_id" 
];
    
    var inputs_check = ["Name missing"];

    var called_table = 'parent';


      var arr_data = []

        const All_data_obj = {};
        All_data_obj.table_ = called_table;
        All_data_obj.inputs_col_ = inputs_col;
        All_data_obj.inputs_check_ = inputs_check;
        All_data_obj.Database_link = Database_link;
        All_data_obj.callbackfunc;
        All_data_obj.obj;
    

    $(document).ready(function () {

        $('#send_group').click(function () {


            if(st_ids == 0)
            {
                alert('No Student Added' , "danger");
                return ;
            }


            for(var index = 0 ; index < st_ids ; index++)
            {
        
                var value_elments = [];
                value_elments[0] = document.getElementById('student_id'+index).value;
                value_elments[1] = document.getElementById('name_id'+index).value;
                value_elments[2] = document.getElementById('bd_id'+index).value;
                value_elments[3] = document.getElementById('status_id'+index).value;

                var labels = ['Student Id missing' , 'Name missing' , 'Birthdate missing' , 'Status missing']

                for(var i = 0 ; i <value_elments.length ; i++ )
                {
                    if(value_elments[i] == '')
                    {
                        alert('Students '+(index+1)+ ' ' + labels[i] , "danger");
                        return ;    
                    }

                }

            }



            var value_elments = [];

            for(var index = 0 ;index < paper_inputs.length ; index++)
            {
             value_elments[index] = document.getElementById(paper_inputs[index] ).value;
            }

            for(var index = 0 ;index < 7 ; index++)
            {
                if(value_elments[index] == "")
                {
                    alert(All_data_obj.inputs_check_[index] , "danger");
                    return;
                }
            }

            All_data_obj.callbackfunc = function(All_data_obj , response)
            {

                All_data_obj.callbackfunc = function(All_data_obj, response)
                {
                    var parent_id =  All_data_obj.obj[All_data_obj.obj.length-1].id;

                    add_new_student(All_req_obj,paper_inputs , parent_id );
                    
                };
                get_all_data_from_database(All_data_obj);


                //get_paper_tables(All_req_obj,quary_tables_all_paper, create_paper_table , 5 , 3);
            };
            add_one_data_from_database(All_data_obj , value_elments);
        
        });
    });
        
}


function add_new_student(All_req_obj,paper_inputs , parent_id )
{
    
    var Database_link = "http://localhost/iSchool/fetch.php"

    var inputs_col = 
    ["std_id" 
    , "parent_id" 
    , "free_session_status" 
    , "std_status" 
    , "name" 
    , "age" 
    , "birthdate" 

];
    
    var inputs_check = ["Name missing"];

    var called_table = 'students';

    if(st_ids == 0)
    {
        alert("Parent Add Successfully - No Student" , "primary");
        ADD_NEW_PARENT();
        return;
    }

    for(var index = 0 ; index < st_ids ; index++)
    {

      var arr_data = []

        const All_data_obj = {};
        All_data_obj.table_ = called_table;
        All_data_obj.inputs_col_ = inputs_col;
        All_data_obj.inputs_check_ = inputs_check;
        All_data_obj.Database_link = Database_link;
        All_data_obj.callbackfunc;
        All_data_obj.obj;

        var years_old = Todate(document.getElementById('bd_id'+index).value)[4];
        var years_current = Todate(new Date())[4];
        var saved_age_range = 0;
        var age_range = years_current - years_old;

        for(var i = 0 ; i < saved_age_arr.length ; i++)
        {
            if(age_range >= saved_age_arr[i][1] && age_range <= saved_age_arr[i][2])
            {
                saved_age_range = saved_age_arr[i][0];
            }
        }

        if(saved_age_range == 0){saved_age_range = 'under age';}



       var value_elments = [];
            value_elments[0] = document.getElementById('student_id'+index).value;
            value_elments[1] = parent_id;
            value_elments[2] = document.getElementById('free_id'+index).value;
            value_elments[3] = document.getElementById('status_id'+index).value;
            value_elments[4] = document.getElementById('name_id'+index).value;
            value_elments[5] = saved_age_range;
            value_elments[6] = document.getElementById('bd_id'+index).value;



            if(value_elments[0] == '' && index == 0)
            {

                alert("Parent Add Successfully - No Student" , "primary");
                ADD_NEW_PARENT();
                return;
            }

            var group_id_value = document.getElementById('groups_id_input'+index).value;

            All_data_obj.callbackfunc = function(All_data_obj , response)
            {
                  All_data_obj.callbackfunc = function(All_data_obj, response)
                {
                    var student_id =  All_data_obj.obj[All_data_obj.obj.length-1].id;
                    add_student_to_group(All_req_obj,paper_inputs , student_id , group_id_value , value_elments[6]);
                    
                };
                get_all_data_from_database(All_data_obj);


            };
            add_one_data_from_database(All_data_obj , value_elments);
        }    
}


function add_student_to_group(All_req_obj,paper_inputs , student_id , group_id_value , student_age)
{
    
    var Database_link = "http://localhost/iSchool/fetch.php"

    var inputs_col = 
    ["groups_id" 
    , "student_id" 
    , "status" 

];
    
    var inputs_check = ["Name missing"];

    var called_table = 'student_groups';


      var arr_data = []

        const All_data_obj = {};
        All_data_obj.table_ = called_table;
        All_data_obj.inputs_col_ = inputs_col;
        All_data_obj.inputs_check_ = inputs_check;
        All_data_obj.Database_link = Database_link;
        All_data_obj.callbackfunc;
        All_data_obj.obj;

       var value_elments = [];
            value_elments[0] = group_id_value;
            value_elments[1] = student_id ;
            value_elments[2] = 'active';

            if(value_elments[0] == "")
            {
                alert("Parent Add Successfully - Student Add Successfully - No group" , "primary");
                ADD_NEW_PARENT();
                return ;
            }

            var years_old = Todate(student_age)[4];
            var years_current = Todate(new Date())[4];
            var compare = 0;
            var age_range = years_current - years_old;

            for(var i = 0 ; i < saved_age_arr.length ; i++)
            {
                if(saved_age_arr[i][0] == 'B')
                {
                    compare = Number(saved_age_arr[i][1]);
                }
            }
            
                  All_data_obj.callbackfunc = function(All_data_obj, response)
                {


                    // console.log(All_data_obj.obj);
                    var counter_full_check = 0;

                        for(var index = 0 ; index < All_data_obj.obj.length ; index ++)
                        {
                            if(group_id_value == All_data_obj.obj[index].groups_id && 'active' == All_data_obj.obj[index].status)
                            {
                                counter_full_check++;
                            }
    
                        }

                        if(age_range < compare)
                        {
                            alert("Parent Add Successfully - Student Add Successfully - Student too Young to join Group" , "danger");
                            ADD_NEW_PARENT();
                            return;
                        }

                        if(counter_full_check >= 6)
                        {
                            alert("Parent Add Successfully - Student Add Successfully - Group Full" , "primary");
                            ADD_NEW_PARENT();
                            return ;
                        }
                    

                    All_data_obj.callbackfunc = function(All_data_obj , response)
                    {
                        
                        alert("Parent Add Successfully - Student Add Successfully - Group Add Successfully" , "success");
                        ADD_NEW_PARENT();
                    };
                    add_one_data_from_database(All_data_obj , value_elments);
                    
                };
                get_all_data_from_database(All_data_obj);
}


function get_paper_tables_parent(All_req_obj , func_quary,func , timeout , index_pos)
{

    var Database_link = All_req_obj.Database_link;
    var inputs_col = All_req_obj.inputs_col; 
    var called_table = All_req_obj.called_table;


      const All_table_obj = {};
      All_table_obj.tables= [];


      var arr_data = [];
    for(var index = 0 ; index < inputs_col.length ; index ++)
    {
        const All_data_obj = {};
        All_data_obj.table_ = called_table[index];
        All_data_obj.inputs_col_ = inputs_col[index];
        All_data_obj.Database_link = Database_link;
        All_data_obj.callbackfunc;
        All_data_obj.obj;
        All_data_obj.index = index;
        All_data_obj.length = inputs_col.length-1;
        All_data_obj.check = false;
        
        arr_data[index] = All_data_obj;
    }


    for(var index = 0 ; index < arr_data.length ; index++)
    {
        arr_data[index].callbackfunc = function(All_data_obj)
        {
            All_table_obj.tables[All_data_obj.index] = All_data_obj.obj;
            All_data_obj.check = true;
        };
        get_all_data_from_database(arr_data[index]);
    }
    counter__[index_pos] = 0;
    again(All_table_obj , arr_data ,   func_quary , func , timeout , index_pos);

}

 function again(All_table_obj , arr_data , func_quary ,  func , timeout , index_pos )
 {

    setTimeout(function () {
        
        for(var index = 0 ; index < arr_data.length ; index++)
        {
            if(arr_data[index].check == false)
            {   
                counter__[index_pos]++;
                again(All_table_obj , arr_data , func_quary ,  func , timeout , index_pos );
            }
        }
        if(func_quary)
        {
            counter__[index_pos]--;
            if(counter__[index_pos] == -1)
            {
                func_quary(All_table_obj , func)

            }

        }
    }, timeout);
 }

 function quary_tables_all_parent(All_table_obj , func)
 {
    var create_new_tabl_rows = []
    var counter = 0;

    if(All_table_obj.tables[4] && All_table_obj.tables[4] !== undefined && All_table_obj.tables[4].length != 0)
    {
        for(var index = 0 ; index < All_table_obj.tables[4].length ; index++)
        {
            counter = 0;
            var create_new_tabl_cols = []
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].id;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].name;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].phone;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].email;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].name_2;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].phone_2;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].email_2;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].address;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].location;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].job;counter++;
            create_new_tabl_cols[counter] = All_table_obj.tables[4][index].reg_status;counter++;

            var return_data = search_two_tables(All_table_obj.tables[4][index] , All_table_obj.tables[3] , 12 , 0 , 2)
            for(var index_ = 0 ; index_ < return_data.length ; index_++)
            {
                create_new_tabl_cols[counter] = return_data[index_];counter++;
            }

            var return_data = search_two_tables(All_table_obj.tables[4][index] , All_table_obj.tables[3] , 13 , 0 , 2)
            for(var index_ = 0 ; index_ < return_data.length ; index_++)
            {
                create_new_tabl_cols[counter] = return_data[index_];counter++;
            }

                    var count_arr = [];
                    var count_num = 0

                    var return_data = search_two_tables(All_table_obj.tables[4][index] , All_table_obj.tables[5] , 0 , 3 , 2)
                    count_arr[count_num] = return_data;count_num++;

                    var return_data = search_two_tables(All_table_obj.tables[4][index] , All_table_obj.tables[5] , 0 , 3 , 4)
                    count_arr[count_num] = return_data;count_num++;

                    var return_data = search_two_tables(All_table_obj.tables[4][index] , All_table_obj.tables[5] , 0 , 3 , 5)
                    var return_data = search_for_data(All_table_obj.tables[9] , return_data , 0 , 2 );
                    count_arr[count_num] = return_data;count_num++;


                    var return_data = search_two_tables(All_table_obj.tables[4][index] , All_table_obj.tables[5] , 0 , 3 , 6)
                    count_arr[count_num] = return_data;count_num++;

                    var return_data = search_two_tables(All_table_obj.tables[4][index] , All_table_obj.tables[5] , 0 , 3 , 7)
                    count_arr[count_num] = return_data;count_num++;

                    create_new_tabl_cols[counter] = count_arr;counter++;

                    var return_data = search_two_tables(All_table_obj.tables[4][index] , All_table_obj.tables[5] , 0 , 3 , 0);
                    var return_data = search_for_data_custom(All_table_obj.tables[8] , return_data , 3 , 2 );
                    var return_data_1 = search_for_data_all(All_table_obj.tables[6] , return_data , 0 , 2 );

                for(var index__ = 0 ; index__ < return_data_1.length ; index__++)
                {
                    if(return_data_1[index__])
                    {
                        var count_arr = [];
                        var count_num = 0
                        count_arr[count_num] = "Group "+(index__+1)+" : ";count_num++;

                        var return_data = search_for_data_index(All_table_obj.tables[10] , return_data_1[index__][2] , 0 , 3 );
                        count_arr[count_num] = return_data;count_num++;

    
                        var return_data = search_for_data_index(All_table_obj.tables[11] , return_data_1[index__][3] , 0 , 2 );
                        count_arr[count_num] = return_data;count_num++;
    
    
    
                        var return_data = search_for_data_index(All_table_obj.tables[12] , return_data_1[index__][4] , 0 , 2 );
                        count_arr[count_num] = return_data;count_num++;
    
                        var return_data = search_for_data_index(All_table_obj.tables[13] , return_data_1[index__][5] , 0 , 2 );
                        count_arr[count_num] = return_data;count_num++;
    
                        // var return_data = search_for_data_index(All_table_obj.tables[14] , return_data_1 , 0 , 2 );
                        // create_new_tabl_cols[counter] = return_data;counter++;
    
                        var return_data = search_for_data_index(All_table_obj.tables[15] , return_data_1[index__][7] , 0 , 2 );
                        count_arr[count_num] = return_data;count_num++;
                        
                        var return_data = search_for_data_index(All_table_obj.tables[16] , return_data_1[index__][8] , 0 , 2 );
                        count_arr[count_num] = return_data;count_num++;
    
                        var return_data = search_for_data_index(All_table_obj.tables[17] , return_data_1[index__][9] , 0 , 2 );
                        count_arr[count_num] = return_data;count_num++;

                        create_new_tabl_cols[counter] = count_arr;counter++;
                    }
                }

        
            create_new_tabl_rows[index] = create_new_tabl_cols;
        }
    }
    func(create_new_tabl_rows);
}



 function quary_tables_all_status_parent(create_new_tabl_rows)
 {
        for(var index_ = 0 ; index_ < create_new_tabl_rows.length ; index_++)
        {
            if(create_new_tabl_rows[index_][7] == 'Customer Support' )
            {
                $('#customer_input').append(`<option value="${create_new_tabl_rows[index_][0]}"
                >${create_new_tabl_rows[index_][1]} </option>`); 
            }

            if(create_new_tabl_rows[index_][7] == 'Sales' )
            {
                $('#sales_input').append(`<option value="${create_new_tabl_rows[index_][0]}"
                >${create_new_tabl_rows[index_][1]} </option>`); 
            }
        }

 }


 function create_paper_table_parent(all_tables)
 {
    var inputs_names_search = [
        "ID :"
    ,"Name :"
    ,"Phone :" 
    , "Email :" 
    , "Name 2 :" 
    , "Phone 2 :" 
    , "Email 2 :"
    , "Address :"
    , "Location :"
    , "Job :"
    , "Reg Status :"
    , "Customer Support Agent :"
    , "Sales Agent :"


];

    const All_data_obj = {};
    All_data_obj.Start_Index = 1;
    All_data_obj.next_btn = '#btn2';
    All_data_obj.prev_btn = '#btn1';
    All_data_obj.ind_btn = '#page_index';
    All_data_obj.location_index = "Location_4";
    All_data_obj.table_div = 'search-results';
    All_data_obj.all_names = inputs_names_search;
    All_data_obj.location_next = "Location_3";
    All_data_obj.Location_2 = "Location_2";
    All_data_obj.location_1 = "Location_1";
    All_data_obj.btn_index = 'btn_index';
    All_data_obj.btn_index = 'btn_index';
    All_data_obj.edit_index = [];
    All_data_obj.delete_index = [];
    All_data_obj.index_num_value = [];
    All_data_obj.obj;

    createTable(all_tables ,All_data_obj , 'clear' , 6 , 4); 
}

function create_paper_table_customized_parent(all_tables)
{



    var inputs_names_search = [
        "ID :"
    ,"Name :"
    ,"Phone :" 
    , "Email :" 
    , "Name 2 :" 
    , "Phone 2 :" 
    , "Email 2 :"
    , "Address :"
    , "Location :"
    , "Job :"
    , "Reg Status :"
    , "Customer Support Agent :"
    , "Sales Agent :"


];


   const All_data_obj = {};
   All_data_obj.Start_Index = 1;
   All_data_obj.next_btn = '#btn2';
   All_data_obj.prev_btn = '#btn1';
   All_data_obj.ind_btn = '#page_index';
   All_data_obj.location_index = "Location_4";
   All_data_obj.table_div = 'search-results';
   All_data_obj.all_names = inputs_names_search;
   All_data_obj.location_next = "Location_3";
   All_data_obj.Location_2 = "Location_2";
   All_data_obj.location_1 = "Location_1";
   All_data_obj.btn_index = 'btn_index';
   All_data_obj.btn_index = 'btn_index';
   All_data_obj.edit_index = [];
   All_data_obj.delete_index = [];
   All_data_obj.index_num_value = [];
   All_data_obj.obj;

   var values_ = document.getElementById("search_all").value;

   if(values_ == "")
   {
      All_data_obj.Start_Index = 1;
      createTable(all_tables ,All_data_obj , 'clear' , 6 , 4);
      return;
   }

    var result = Search_for_value(all_tables , values_)
        
   createTable(result ,All_data_obj , 'clear' , 6 , 4); 
}

function paper_inner_parent (paper_ , title)
{
  document.getElementById("Location_1").innerHTML += `<label for="`+paper_+`">`+title+`:</label>
  <select class='col-1' name="`+paper_+`" id="`+paper_+`">
  <option value=""></option>
  </select>` ;
}

function paper_inner_parent_1 (paper_ , title)
{
  document.getElementById("Location_2").innerHTML += `<label for="`+paper_+`">`+title+`:</label>
  <select class='col-1' name="`+paper_+`" id="`+paper_+`">
  <option value=""></option>
  </select>` ;
}

function quary_tables_all_status_groups_check(All_table_obj , func)
{
    var seached_rows = [];
    saved_group_arr = [];
    var saved_group_arr_col = [];
    var special_counter = 0;

    if(All_table_obj.tables[11] && All_table_obj.tables[11] !== undefined && All_table_obj.tables[11].length != 0){

        var saved_status_arr_row = [];
        for(var index = 0 ; index < All_table_obj.tables[11].length ; index ++)
        {
            saved_status_arr_row = [];
            saved_status_arr_row[0] = All_table_obj.tables[11][index].id;
            saved_status_arr_row[1] = All_table_obj.tables[11][index].name;
            saved_status_arr[index] = saved_status_arr_row;
        }
    }

    if(All_table_obj.tables[7] && All_table_obj.tables[7] !== undefined && All_table_obj.tables[7].length != 0)
    {
        for(var index = 0 ; index < All_table_obj.tables[7].length ; index ++)
        {
            var saved_age_arr_rows = []
            saved_age_arr_rows[0] = All_table_obj.tables[7][index].name;
            saved_age_arr_rows[1] = All_table_obj.tables[7][index].from_age;
            saved_age_arr_rows[2] = All_table_obj.tables[7][index].to_age;
            saved_age_arr[index] = saved_age_arr_rows;
        }
    }

    if(All_table_obj.tables[8] && All_table_obj.tables[8] !== undefined && All_table_obj.tables[8].length != 0){
                                            
        for(var index_ = 0 ; index_ < All_table_obj.tables[8].length ; index_++)
        {
            var seached_cols = [];
            var counter = 0;
            saved_group_arr_col = [];
            seached_cols[counter] = All_table_obj.tables[8][index_].id;counter++;

            if(All_table_obj.tables[0] && All_table_obj.tables[0] !== undefined && All_table_obj.tables[0].length != 0){

                for(var index = 0 ; index < All_table_obj.tables[0].length ; index ++)
                {
                    if(All_table_obj.tables[8][index_].slot_id == All_table_obj.tables[0][index].id)
                    {
                        seached_cols[counter] = All_table_obj.tables[0][index].name;counter++
                        seached_cols[counter] = All_table_obj.tables[0][index].slot;counter++
                        break;
                    }
                }
            }

            if(All_table_obj.tables[1] && All_table_obj.tables[1] !== undefined && All_table_obj.tables[1].length != 0){

                for(var index = 0 ; index < All_table_obj.tables[1].length ; index ++)
                {
                    if(All_table_obj.tables[8][index_].lan_id == All_table_obj.tables[1][index].id)
                    {
                        seached_cols[counter] = All_table_obj.tables[1][index].name;counter++
                        break;
                    }
                }
            }
            if(All_table_obj.tables[2] && All_table_obj.tables[2] !== undefined && All_table_obj.tables[2].length != 0){

                for(var index = 0 ; index < All_table_obj.tables[2].length ; index ++)
                {
                    if(All_table_obj.tables[8][index_].att_id == All_table_obj.tables[2][index].id)
                    {
                        seached_cols[counter] = All_table_obj.tables[2][index].name;counter++
                        break;
                    }
                }
            }
            if(All_table_obj.tables[3] && All_table_obj.tables[3] !== undefined && All_table_obj.tables[3].length != 0){

                for(var index = 0 ; index < All_table_obj.tables[3].length ; index ++)
                {
                    if(All_table_obj.tables[8][index_].level_id == All_table_obj.tables[3][index].id)
                    {
                        seached_cols[counter] = All_table_obj.tables[3][index].name;counter++
                        break;
                    }
                }
            }
            if(All_table_obj.tables[4] && All_table_obj.tables[4] !== undefined && All_table_obj.tables[4].length != 0){

                for(var index = 0 ; index < All_table_obj.tables[4].length ; index ++)
                {
                    if(All_table_obj.tables[8][index_].track_id == All_table_obj.tables[4][index].id)
                    {
                        seached_cols[counter] = All_table_obj.tables[4][index].name;counter++
                        break;
                    }
                }
            }

            if(All_table_obj.tables[5] && All_table_obj.tables[5] !== undefined && All_table_obj.tables[5].length != 0){

                for(var index = 0 ; index < All_table_obj.tables[5].length ; index ++)
                {
                    if(All_table_obj.tables[8][index_].type_id == All_table_obj.tables[5][index].id)
                    {
                        seached_cols[counter] = All_table_obj.tables[5][index].name;counter++
                        break;
                    }
                }
            }
            if(All_table_obj.tables[6] && All_table_obj.tables[6] !== undefined && All_table_obj.tables[6].length != 0){

                for(var index = 0 ; index < All_table_obj.tables[6].length ; index ++)
                {
                    if(All_table_obj.tables[8][index_].days_id == All_table_obj.tables[6][index].id)
                    {
                        seached_cols[counter] = All_table_obj.tables[6][index].name;counter++
                        break;
                    }
                }
            }
            if(All_table_obj.tables[7] && All_table_obj.tables[7] !== undefined && All_table_obj.tables[7].length != 0){

                for(var index = 0 ; index < All_table_obj.tables[7].length ; index ++)
                {
                    if(All_table_obj.tables[8][index_].age_id == All_table_obj.tables[7][index].id)
                    {
                        seached_cols[counter] = All_table_obj.tables[7][index].name;counter++
                        break;
                    }
                }
            }



            
            var counter__ = 0;
            if(All_table_obj.tables[10] && All_table_obj.tables[10] !== undefined && All_table_obj.tables[10].length != 0)
            {
                for(var index = 0 ; index < All_table_obj.tables[10].length ; index++)
                {
                    if((All_table_obj.tables[8][index_].id == All_table_obj.tables[10][index].groups_id) && (All_table_obj.tables[10][index].status == "active"))
                    {
                        counter__++;
                    }
                }
            }

            saved_group_arr_col[0] = All_table_obj.tables[8][index_].id;
            saved_group_arr_col[1] = `${seached_cols[9]}-${seached_cols[5]}-`+All_table_obj.tables[8][index_].id+` | ${seached_cols[8]}-${seached_cols[2]} | ${seached_cols[7]}-${seached_cols[3]} | `+counter__+`-St`;
            

            saved_group_arr[special_counter] = [];
            if(counter__ < 6)
            {
             saved_group_arr[special_counter] = saved_group_arr_col;
             special_counter++;
            }
        }

        if(All_table_obj.tables[9] && All_table_obj.tables[9] !== undefined && All_table_obj.tables[9].length != 0){

            for(var index_ = 0 ; index_ < All_table_obj.tables[9].length ; index_++)
            {
                // $('#student_input').append(`<option value="${All_table_obj.tables[9][index_].id}"
                // >${All_table_obj.tables[9][index_].std_id}  </option>`);  
            }
        }

    }



}